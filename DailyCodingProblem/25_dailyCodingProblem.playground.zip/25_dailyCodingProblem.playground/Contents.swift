/*
 Asked by Facebook
 Level: [Hard]
 Implement regular expression matching with the following special characters:
 
 . (period) which matches any single character
 * (asterisk) which matches zero or more of the preceding element
 That is, implement a function that takes in a string and a valid regular expression and returns whether or not the string matches the regular expression.
 
 For example, given the regular expression "ra." and the string "ray", your function should return true. The same regular expression on the string "raymond" should return false.
 
 Given the regular expression ".*at" and the string "chat", your function should return true. The same regular expression on the string "chats" should return false.
 
 */
import Cocoa

var regExp: String = ".*at"
var str: String = "chats"
var genVal: Bool = false
var countVal: Int = 0

for char in regExp {
    for letter in str {
        if (char == ".") || (char == "*") || (char == letter) {
            countVal += 1; break
        } else { genVal = false }
    }
}

if !(countVal < str.count) { genVal = true }
print("Matching string: \(str) and regExp: \(regExp):\n\(genVal)")
