import Cocoa

var arrayA: [Int] = [3, 5, 6, 8, 2, 1, 4]
var arrayB: [Int] = []
var tempNumber: Int = 1

for indexA in arrayA {
    for indexB in arrayA {
        if indexA != indexB {
            tempNumber *= indexB
        }
    }
    arrayB.append(tempNumber)
    tempNumber = 1
}
print(arrayA)
print(arrayB)



