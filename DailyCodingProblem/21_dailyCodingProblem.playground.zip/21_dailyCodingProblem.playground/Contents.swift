//This problem was asked by Snapchat.
//Given an array of time intervals (start, end) for classroom lectures (possibly overlapping), find the minimum number of rooms required.
//For example, given [(30, 75), (0, 50), (60, 150)], you should return 2.

import Cocoa

var classroomLectures = [[30, 75], [0, 50], [60, 150], [40, 120]]
var contL = 0
var contG = 0

for i in classroomLectures {
    for k in classroomLectures {
        if k == i {
            break
        }
        for j in 0...1 {
            switch j {
            case 0:
                if i[j] < k[j+1] && i[j] < k[j] {
                    contL += 1
                }
            case 1:
                if i[j] < k[j] && i[j] < k[j-1] {
                    contL += 1
                }
            default:
                print("error no value j")
            }
        }
    }
    if contL > 0 {
        contG += 1
    }
}

print(contG)
