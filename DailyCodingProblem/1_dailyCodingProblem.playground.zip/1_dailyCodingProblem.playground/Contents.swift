/*
 Daily Coding Problem #1. Asked by Google.
 Given a list of numbers and a number k, return whether any two numbers from the list add up to k.
 For example, given [10, 15, 3, 7] and k of 17, return true since 10 + 7 is 17.
 Bonus: Can you do this in one pass?
 */
import Cocoa

let randomNumbersInTheArray: Int =  Int.random(in: 2..<11)
let k: Int = Int.random(in: 2..<10)
var foundMatch: Bool = false
var arrayRandomNumbers: [Int] = []

private func createArray() {
    for _ in 0...randomNumbersInTheArray {
        let singleNumber: Int = Int.random(in: 1..<6)
        arrayRandomNumbers.append(singleNumber)
    }
    
    print("Array: \(arrayRandomNumbers)")
    print("K: \(k)\n")
}

private func checkArray() {
    for i in arrayRandomNumbers {
        if foundMatch == true {
            break
        }
        for j in arrayRandomNumbers {
            if i != j {
                if (i + j) == k {
                    foundMatch = true
                    print("Found: \(i + j) and \(k)")
                    break
                }
            }
        }
    }
}

createArray()
checkArray()
