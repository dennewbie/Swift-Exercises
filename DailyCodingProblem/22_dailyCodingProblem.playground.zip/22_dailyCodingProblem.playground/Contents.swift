/*This problem was asked by Microsoft.

Given a dictionary of words and a string made up of those words (no spaces), return the original sentence in a list. If there is more than one possible reconstruction, return any of them. If there is no possible reconstruction, then return null.

For example, given the set of words 'quick', 'brown', 'the', 'fox', and the string "thequickbrownfox", you should return ['the', 'quick', 'brown', 'fox'].

Given the set of words 'bed', 'bath', 'bedbath', 'and', 'beyond', and the string "bedbathandbeyond", return either ['bed', 'bath', 'and', 'beyond] or ['bedbath', 'and', 'beyond'].
*/

import Cocoa

//var mainString: String = "thequickbrownfox"
var mainString: String = "bedbathandbeyond"
//var arrWord: [String] = ["quick", "brown", "the", "fox"]
var arrWord: [String] = ["bed", "bath", "bedbath", "and", "beyond"]
var newArrWord: [String] = []
var newString: String = ""

for word in arrWord {
    for letter in mainString {
        print(newString)
        print(word)
        if newString == word {
            newArrWord.append(newString)
            newString = ""
        } else {
            if let idx = word.firstIndex(of: letter) {
                newString.append(letter)
            }
        }
    }
    newString = ""
}
print(newArrWord)
