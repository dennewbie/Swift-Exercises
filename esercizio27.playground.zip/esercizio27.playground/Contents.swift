import Cocoa
//27. Write a Swift program to count the number of times that two 7's are next to each other in a given array of integers
var str = "Hello, playground"

func check(arrayInt: [Int]) -> Int{
    var nOfTimes: Int = 0
    var count: Int = Int()
    print(arrayInt.count)

//    var startIndex: Int = arrayInt.index(after: arrayInt.startIndex)
//    var endIndex: Int = arrayInt.index(before: arrayInt.endIndex)
   for items in arrayInt {
     
        if arrayInt.count - 1 != count {
            if items == arrayInt[count + 1] {
                nOfTimes += 1
            }
        }
     count += 1
    }
    return nOfTimes
}
    


var arrayInt: [Int] = [0, 3, 7, 7, 8, 1]
print(check(arrayInt: arrayInt))
