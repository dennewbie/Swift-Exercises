import Cocoa
//19. Write a Swift program to convert the last three characters in upper case. If the string has less than 3 chars, lowercase whatever is there.
var str = "Hello, playground"


func convert(stringaValue: String) -> String {
    var stringa: String = stringaValue
    if (stringa.count < 3){
        stringa = stringa.lowercased()
    } else {
        stringa = stringa.uppercased()
    }
    return stringa
}


print(convert(stringaValue: "CA"))
print(convert(stringaValue: "Mariooone"))
print(convert(stringaValue: "Pir"))

