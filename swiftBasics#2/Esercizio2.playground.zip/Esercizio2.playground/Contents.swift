import Cocoa
//Write a Swift program to compute and return the absolute difference of n and 51, if n is over 51 return double the absolute difference

let secondNumber: Int = 51
var firstNumber: Int = 30

func absDifference(firstNumber: Int, secondNumber: Int){
    var difference: Int
    if firstNumber > secondNumber {
        difference = (firstNumber - secondNumber) * 2
    } else {
        difference = abs((firstNumber - secondNumber))
    }
    
    print(difference)
}

absDifference(firstNumber: firstNumber, secondNumber: secondNumber)
absDifference(firstNumber: 30, secondNumber: 10)
