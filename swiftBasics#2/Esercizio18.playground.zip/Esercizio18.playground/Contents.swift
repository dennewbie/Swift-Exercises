import Cocoa
//18. Write a Swift program to test whether the last digit of the two given non-negative integer values are same or not.
var str = "Hello, playground"

func check(numUno: Int, numDue: Int) -> Bool {
    if (numUno > 0 && numDue > 0) {
        
        if (numUno % 10 == numDue % 10) {
        return true
    } else {
        return false
    }
    } else {
        return false
    }
}

print(check(numUno: 10, numDue: 100))
print(check(numUno: 44, numDue: 33))
print(check(numUno: 22, numDue: 16))
print(check(numUno: 56, numDue: 36))

