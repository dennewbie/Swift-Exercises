import Cocoa
//10. Write a Swift program to take the first two characters from a given string and create a new string with the two characters added at both the front and back.
var str = "Hello, playground"


func change(firstString: String, secondString: String) -> String {
    var firstString: String = firstString
    var secondString: String = secondString
    var countFirst: Int = firstString.count
    var finalString: String!
    
    if countFirst >= 1 {
        let substringStart = secondString.prefix(2)
        finalString = substringStart + firstString + substringStart
    }
    return finalString
}
var firstString: String = "Cacca"
var secondString: String = "Cavolfiore"
print(change(firstString: firstString, secondString: secondString))

firstString = "Swift"
secondString = "Apple"
print(change(firstString: firstString, secondString: secondString))

firstString = "Minnie"
secondString = "Topolino"
print(change(firstString: firstString, secondString: secondString))
