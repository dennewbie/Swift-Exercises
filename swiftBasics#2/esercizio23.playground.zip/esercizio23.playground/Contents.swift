import Cocoa
//23. Write a Swift program to check if one of the first 4 elements in a given array of integers is a 7. The length of the array may be less than 4
var str = "Hello, playground"

func check(arrayInt: [Int]) -> Bool {
    var ret: Bool = false
    if arrayInt.count <= 4 {
        
        for items in arrayInt {
            if items == 7 {
                ret = true
            }
        }
        return ret
    } else {
        return ret
    }
}

var arrayInt: [Int] = [3, 5, 6, 7]
print(check(arrayInt: arrayInt))
