import Cocoa
//16. Write a Swift program that accept two integer values and test if they are both in the range 20..30 inclusive, or they are both in the range 30..40 inclusive
var str = "Hello, playground"

func check(numUno: Int, numDue: Int){
    if (numUno > 20 && numUno <= 30) && (numDue > 20 && numDue <= 30){
        print("Sono entrambi nel ragne 20...30 \(numUno) e \(numDue)")
    } else if (numUno > 30 && numUno <= 40) && (numDue > 30 && numDue <= 40){
        print("Sono entrambi nel ragne 30...40 \(numUno) e \(numDue)")
    } else {
        print("Non sono nei ragne descritti \(numUno) e \(numDue)")
    }
}


check(numUno: 10, numDue: 20)
check(numUno: 21, numDue: 30)
check(numUno: 37, numDue: 34)
check(numUno: 30, numDue: 20)
