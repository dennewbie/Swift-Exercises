import Cocoa
//3. Write a Swift program that accept two integer values and return true if one of them is 20 or if their sum is 20
var str = "Hello, playground"

func check(firstNumber: Int, secondNumber: Int) -> Bool{
    var returnThis: Bool
    if (firstNumber == 20 || secondNumber == 20 || firstNumber + secondNumber == 20){
        returnThis = true
    } else {
        returnThis = false
    }
    return returnThis
}

print(check(firstNumber: 8, secondNumber: 12))
print(check(firstNumber: 20, secondNumber: 40))
print(check(firstNumber: 40, secondNumber: 80))

