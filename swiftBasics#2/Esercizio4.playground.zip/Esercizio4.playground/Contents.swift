import Cocoa
//4. Write a Swift program to accept two integer values and return true if one is negative and one is positive. Return false only if both are negative

var str = "Hello, playground"

func check(firstNumber: Int, secondNumber: Int) -> Bool {
    var returnThis: Bool
    if (firstNumber > 0 && secondNumber < 0) || (firstNumber < 0 && secondNumber > 0) {
        returnThis = true
    } else if (firstNumber < 0 && secondNumber < 0 ){
        returnThis = false
    } else {
        print("Your numbers don't respect my rules")
        returnThis = false
    }
    return returnThis
}

print(check(firstNumber: 20, secondNumber: -10))
print(check(firstNumber: 40, secondNumber: 10))
print(check(firstNumber: -10, secondNumber: -10))
