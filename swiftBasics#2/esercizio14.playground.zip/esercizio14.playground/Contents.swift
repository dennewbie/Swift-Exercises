import Cocoa
//14. Write a Swift program to find the largest number among three given integers.
var str = "Hello, playground"

func check(numOne: Int, numTwo: Int, numThree: Int){
    var num: [Int] = [numOne, numTwo, numThree]
    
    var max: Int = 0
    
    for item in num {
        if item > max {
            max = item
        }
    }
    
    print("Max: \(max)")
}

var numOne: Int = 5
var numTwo: Int = 2
var numThree: Int = 10

check(numOne: numOne, numTwo: numTwo, numThree: numThree)

numOne = 100
numTwo = 101
numThree = 99

check(numOne: numOne, numTwo: numTwo, numThree: numThree)
