import Cocoa
//15. Write a Swift program that accept two integer values and to test which value is nearest to the value 10, or return 0 if both integers have same distance from 10.
var str = "Hello, playground"

func check(numeroUno: Int, numeroDue: Int) -> Int {
    let numFinal: Int = advancedCheck(numeroSent: numeroUno)
    let numFinalDue: Int = advancedCheck(numeroSent: numeroDue)
    
    if numFinal > numFinalDue {
        return numeroDue
    } else if numFinalDue > numFinal {
        return numeroUno
    } else {
        return 0
    }
}

func advancedCheck(numeroSent: Int) -> Int {
    var numero: Int = numeroSent
    if numero > 10 {
        numero = numero - 10
    } else if numero < 0 {
        numero = numero * -1
        numero = 10 - numero
    } else {
        numero = 10 - numero
    }
    return numero
}


print(check(numeroUno: 2, numeroDue: -2))
