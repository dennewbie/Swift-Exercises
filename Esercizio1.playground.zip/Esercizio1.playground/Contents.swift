import Cocoa
//Write a Swift program to compute the sum of the two integers. If the values are equal return the triple their sum.
var firstNumber: Int = 4
var secondNumber: Int = 5

if firstNumber == secondNumber {
    print("Result: \(3 * (firstNumber + secondNumber))")
} else {
    print("Result: \(firstNumber + secondNumber)")
}

