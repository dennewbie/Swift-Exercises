import Cocoa

var str = "Hello, playground"


class Fruttivendolo {
    
    private var banane: Int
    private var mele: Int
    private var pere: Int
    private var kiwi: Int?
    private var mess: String?
    
    init(banane: Int, mele: Int, pere: Int) {
        self.banane = banane
        self.mele = mele
        self.pere = pere
    }
    
    init(banane: Int, mele: Int, pere: Int, kiwi: Int?) {
        self.banane = banane
        self.mele = mele
        self.pere = pere
        self.kiwi = kiwi
    }
    
    init(banane: Int, mele: Int, pere: Int, kiwi: Int?, mess: String?) {
        self.banane = banane
        self.mele = mele
        self.pere = pere
        self.kiwi = kiwi
        self.mess = mess
    }
    
    public func stampaFrutta() {
        guard kiwi != nil else {
            print("\n\nBanane: \(banane)\nMele: \(mele)\nPere:\(pere)\n")
            return
        }
        print("\n\nBanane: \(banane)\nMele: \(mele)\nPere:\(pere)\nKiwi: \(kiwi!)")
    }
    
    public func aggiungiFrutta (banane: Int?, mele: Int?, pere: Int?, kiwi: Int?) {
        if banane != nil {
            self.banane += banane!
        }
        
        if mele != nil {
            self.mele += mele!
        }
        
        if pere != nil {
            self.pere += pere!
        }
        
        if kiwi != nil {
            self.kiwi? += kiwi!
        }
        
        stampaFrutta()
    }
    
    public func vendiFrutta (banane: Int?, mele: Int?, pere: Int?, kiwi: Int?) {
        if banane != nil {
            if self.banane >= banane! {
                self.banane -= banane!
            }} else if banane == nil {
            
        } else {
            print("Non abbiamo abbastanza banane.")
        }
        
        if mele != nil {
            if self.mele >= mele! {
                self.mele -= mele!
            }} else if mele == nil {
            
        } else {
            print("Non abbiamo abbastanza mele.")
        }
        
        if pere != nil {
            if self.pere >= pere! {
                self.pere -= pere!
            }} else if pere == nil {
            
        } else {
            print("Non abbiamo abbastanza pere.")
        }
        
        if kiwi != nil && self.kiwi != nil {
            if self.kiwi! >= kiwi! {
                self.kiwi! -= kiwi!
            }} else if kiwi == nil {
            
        } else {
            print("Non abbiamo abbastanza kiwi.")
        }
        stampaFrutta()
    }
}

var fruttivendoloPino = Fruttivendolo(banane: 30, mele: 20, pere: 10)
fruttivendoloPino.vendiFrutta(banane: 10, mele: nil, pere: nil, kiwi: 30)

var fruttivendoloGiorgio = Fruttivendolo(banane: 30, mele: 20, pere: 10, kiwi: 5)
fruttivendoloGiorgio.stampaFrutta()
fruttivendoloGiorgio.vendiFrutta(banane: 10, mele: nil, pere: 10, kiwi: 3)
