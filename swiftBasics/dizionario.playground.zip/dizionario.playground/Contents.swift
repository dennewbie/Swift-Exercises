import Cocoa

var str = "Hello, playground"

//dichiara
var dizionario: [Int : String] = [Int : String]()


//inserisci
dizionario.updateValue("Cavolfiore1", forKey: 1)
dizionario.updateValue("Cavolfiore2", forKey: 2)
dizionario.updateValue("Cavolfiore3", forKey: 3)
//printa
for item in dizionario {
    print(item)
}
print("\n")



//rimuovi
dizionario[2] = nil
for item in dizionario {
    print(item)
}
print("\n")



//rimuovi tutti
dizionario.removeAll() 
for item in dizionario {
    print(item)
}
