import Cocoa

var str = "AaHello, playgroundAa"
//Lavorare direttamente sul parametro passato senza passarlo a una variabile interna alla funzione attraverso la parola chiave "inout"
func string_a(_ input: inout String) -> String {
    let index_start = input.index(after: input.startIndex)
    let index_end = input.index(before: input.endIndex)
    let middleRange = index_start ..< index_end
    
    var sub_string = input.substring(with: middleRange)
    
    while sub_string.characters.contains("a") {
        sub_string.remove(at: sub_string.characters.index(of: "a")!)
    }
    
    input.replaceSubrange(middleRange, with: sub_string)
    
    return String(input)
}

var stringa: String = "aaaababaabbbbaaa"
print(string_a(&stringa))

