import Cocoa

var str = "Hello, playground"


//dichiarazione

var tupla: (Int, String) = (Int(), String())

tupla = (20, "Mirko")

//più valori

var tupla2 = ("Mirko", "Matteo", 20, "X")

print("***Elementi Tupla***\n\n\(tupla2.0, tupla2.1, tupla2.2, tupla2.3)")
