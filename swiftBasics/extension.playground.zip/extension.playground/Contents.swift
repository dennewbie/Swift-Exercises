import Cocoa

var str = "Hello, playground"


class Persona {
    private var nome: String
    private var cognome: String
    private var annoNascita: String
    
    var getNome: String {
        get {
            return self.nome
        }
    }
    
    var getCognome: String {
        get {
            return self.cognome
        }
    }
    
    var getAnnoNascita: String {
        get {
            return self.annoNascita
        }
    }
    
    init(nome: String, cognome: String, annoNascita: String) {
        self.nome = nome
        self.cognome = cognome
        self.annoNascita = annoNascita
    }
}


extension Persona {
    internal var codiceFiscale: String {
        get {
            return(nome + "" + cognome + "" + annoNascita)
        }
    }
}

var mario: Persona = Persona(nome: "Mario", cognome: "Rossi", annoNascita: "1986")
print("\n\nIl codice fiscale di \(mario.getCognome) \(mario.getNome) è: \(mario.codiceFiscale)")
