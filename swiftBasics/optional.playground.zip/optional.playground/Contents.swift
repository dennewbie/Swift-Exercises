import Cocoa

var str = "Hello, playground"

//optional means that it may contains or not a value inside it
var numeroDouble: Double?
numeroDouble = 30.4
//optional unwrapping (blinding) easiest way
if numeroDouble == nil {
    print("Numero NIL")
} else {
    //mettere il punto esclamativo nel print per non fare uscire optional(valore contenuto)
    print("Numero Double: \(numeroDouble!)")
}


var nome: String?
nome = "KekkoBombolone"
if nome == nil {
    print("Nome NIL")
} else {
    print("Spelling:\n")
    for letters in nome!.characters {
        print(letters)
    }
}
