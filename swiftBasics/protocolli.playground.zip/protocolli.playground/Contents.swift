import Cocoa

var str = "Hello, playground"

protocol mustDataAndMethods {
    
    var nome: String { get set }
    var cognome: String { get set }
    var annoNascita: String { get }
    var codiceFiscale: String? { get set }
    
    
    func insert()
    func edit()
    func delete()
    func print()
}

class Persona: mustDataAndMethods {
    //MARK: Variables
    internal var nome: String
    internal var cognome: String
    internal var annoNascita: String
    var codiceFiscale: String?
    
    //MARK: Costruttore
    init(nome: String, cognome: String, annoNascita: String) {
        self.nome = nome
        self.cognome = cognome
        self.annoNascita = annoNascita
    }
    

    //MARK: Methods
    func insert(){
    }
    
    func edit(){
    }
    
    func delete(){
    }
    
    func print(){
    }
}
