import Cocoa

var str = "Hello, playground"


func creaCodice(nome: inout String?, cognome: inout String?, year: inout String?) -> String? {
    
    guard var veroNome = nome else { return nil }
    guard var veroCognome = cognome else { return nil }
    guard let veroAnno = year else { return nil }

    veroNome = removeVocals(word: &nome!)
    veroCognome = removeVocals(word: &cognome!)
    
    return veroNome + veroCognome + veroAnno
}


func removeVocals(word: inout String) -> String {
    var count: Int = 0
    var index = word.index(word.startIndex, offsetBy: count)
    var newString: String = String()
    for letters in word.characters {
        if count % 2 == 0 {
            newString.append(letters)
        }
        count += 1
    }
    return newString
}

var nome: String?
var cognome: String?
var year: String?

nome = "Riccardino"
cognome = "Sassolino"
year = "79"
print(creaCodice(nome: &nome, cognome: &cognome, year: &year)!)
