import Cocoa
//quick recap
var str = "Hello, playground"

//array di tuple
var arrayTupla = [(String, Double, String)]()

arrayTupla.append(("Marco", 1.70, "Brown Eyes"))
arrayTupla.append(("George", 1.50, "Gray Eyes"))
arrayTupla.append(("Luke Li", 1.91, "Blue Eyes"))

for item in arrayTupla {
    print("Nome \(item.0)\nHeight: \(item.1)\nEyes: \(item.2)\n")
}


//dizionario contenente array come valore
var dizArray = [String : [Int]]()

print("-------------------")
dizArray["Mirko"] = [3, 6, 7, 8]
dizArray["Luke"] = [5, 7, 2, 5]
dizArray["Denny"] = [6, 7, 8, 10]
dizArray["Mario"] = [4, 7, 3]

print(dizArray)


dizArray["Mario"]?.append(5)

for x in dizArray {
    print("Voti di \(x.key)")
    for j in x.value {
        print(j)
    }
    print("\n")
}
