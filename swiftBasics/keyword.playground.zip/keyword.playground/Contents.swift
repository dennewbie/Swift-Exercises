import Cocoa

var str = "Hello, playground"


var intero = 13
var description = "Il numero \(intero) è un numero"

switch intero {
case 1,2,3,5,7,11,13,17,19,23:
    description.append(" primo")
    fallthrough
default:
    description.append(" intero.")
}


print(description)




var stringa = "aaaaaaaaaaaaaaaaaaa1aaaaaaaa"
var cont: Int = Int()

for letter in stringa.characters {
    cont += 1
    if letter == "1"{
        break
    }
}

print("Intruso trovato alla posizione \(cont)")


var passwordNoCoded: String = "LaMia3SuperPa85ssword6"
var passwordEncoded: String = String()

for letters in passwordNoCoded.characters {
    switch letters {
    case "a", "e", "i", "o", "u", "A", "E", "I", "O", "U":
        continue
    case "1", "2", "3", "4", "5":
        continue
    case "6", "7", "8", "9", "0":
        passwordEncoded.append("%")
        passwordEncoded.append(letters)
    default:
        passwordEncoded.append(letters)
    }
}

print(passwordEncoded)
