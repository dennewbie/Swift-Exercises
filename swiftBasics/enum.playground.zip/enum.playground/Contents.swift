import Cocoa

var str = "Hello, playground"


enum colori: String {
    
    case blu
    case yellow
    case red
    
    var pathPic: String {
        return "\(rawValue).JPG"
    }
}


let image: String = colori.yellow.pathPic
print(image)
