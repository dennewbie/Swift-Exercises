import Cocoa

var str = "Hello, playground"


class Saldo {
    //qui ci vorrebbe il private, solo in questi casi avere doppioni di variabili ha senso
    var conto1: Double
    var conto2: Double {
        get {
            return self.conto1
        }
        
        set(nuovoValore){
            
            if nuovoValore < 0 {
                print("Stai provando a inserire un valore negativo")
                return
            }
            print("Nuovo Valore è di: \(nuovoValore)")
            self.conto1 = nuovoValore
        }
    }
    
    init(conto1: Double) {
        self.conto1 = conto1
    }
}

var saldo: Saldo = Saldo(conto1: 1000)


print("Il saldo del conto1 è: \(saldo.conto1)")
print("Il saldo del conto2 è: \(saldo.conto2)")


saldo.conto2 = 2000

print("Il saldo del conto1 è: \(saldo.conto1)")
print("Il saldo del conto2 è: \(saldo.conto2)")



//altro esempio

class Persona {
    private var nome: String
    private var cognome: String
    private var annoNascita: String
    
    var getNome: String {
        get {
            return self.nome
        }
    }
    
    var getCognome: String {
        get {
            return self.cognome
        }
    }
    
    var getAnnoNascita: String {
        get {
            return self.annoNascita
        }
    }
    
    internal var codiceFiscale: String {
        let codiceFiscoContratto = nome + cognome + annoNascita
        return codiceFiscoContratto
    }
    
    init(nome: String, cognome: String, annoNascita: String) {
        self.nome = nome
        self.cognome = cognome
        self.annoNascita = annoNascita
    }
}

var mario: Persona = Persona(nome: "Mario", cognome: "Rossi", annoNascita: "1986")
print("\n\nIl codice fiscale di \(mario.getCognome) \(mario.getNome) è: \(mario.codiceFiscale)")
