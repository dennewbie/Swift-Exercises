import Cocoa

var str = "Hello, playground"


var ora = 24

switch ora {
case let x where x > 5 && x < 13:
    print("Buongiorno")
    break
case let x where x >= 13 && x < 18:
    print("Buon Pomeriggio")
    break
case let x where x >= 18 && x <= 24:
    print("Buona Sera")
    break
case let x where x <= 5:
    print("Buona Notte")
    break
default:
    print("Il numero inserito non è un'ora perchè è maggiore di 24")
    break
}



var voto = 5

switch voto {
case 0...5:
    print("Voto Insufficiente")
case 6...9:
    print("Buono")
case 10:
    print("Eccellente")
default:
    print("Inserisci un numero compreso tra 0 e 10. Grazie")
}
