import Cocoa
//26. Write a Swift program to create a string taking characters at indexes 0, 2, 4, 6, 8, .. from a given string
var str = "Hello, playground"


func takeChar(stringa: String) -> String {
    var retString: String = stringa
    var count: Int = 0
    var newString: String = String()
    
    for item in retString {
        if (count % 2 == 0){
            newString.append(item)
        }
        count += 1
    }
    return newString
}

print(takeChar(stringa: str))
