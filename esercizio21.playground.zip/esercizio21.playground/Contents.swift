import Cocoa
//21. Write a Swift program to create a string made of every other char starting with the first from a given string. So "Python" will return "Pto"

var str = "Hello, playground"

func check(stringa: String) -> String {
    var finalStringa: String = String()
    var count: Int = 0
    
    for letters in stringa {
        if count % 2 == 0 {
            finalStringa.append(letters)
        }
        count += 1
    }
    return finalStringa
}

print(check(stringa: str))

