import Cocoa
//9. Write a Swift program to check if a given non-negative number is a multiple of 3 or a multiple of 5
var str = "Hello, playground"

func multiplo(numero: Int){
    var conto: Int = 0
    var number: Int = numero
    while number > 0 {
        if number % 3 == 0 {
            number = number - 3
        } else {
            conto = conto + 1
            break
        }
            
        if number == 0 {
            print("\(numero) è un multiplo di tre")
        }
    }
    
    number = numero
        while number > 0 {
            if number % 5 == 0 {
                number = number - 5
            } else {
                    conto = conto + 1
                    break
                }
            }
            if number == 0 {
                print("\(numero) è un multiplo di cinque")
            }
    if conto == 2 {
        print("\(numero) non è un multiplo nè di tre, nè di cinque")
    }
    }


multiplo(numero: 102)
multiplo(numero: 30)
multiplo(numero: 17)
