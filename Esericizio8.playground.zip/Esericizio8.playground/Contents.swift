import Cocoa
//8. Write a Swift program to add the last character (given string) at the front and back of a given string. The length of the given string must be 1 or more
var str = "Hello, playground"

func change(firstString: String, secondString: String) -> String {
    var firstString: String = firstString
    var secondString: String = secondString
    var countFirst: Int = firstString.count
    var finalString: String!
    
    if countFirst >= 1 {
        let substringStart = secondString.prefix(1)
        let substringEnd = secondString.suffix(1)
        finalString = substringStart + firstString + substringEnd
    }
    return finalString
}
var firstString: String = "Cacca"
var secondString: String = "Cavolfiore"
print(change(firstString: firstString, secondString: secondString))

firstString = "Swift"
secondString = "Apple"
print(change(firstString: firstString, secondString: secondString))

firstString = "Minnie"
secondString = "Topolino"
print(change(firstString: firstString, secondString: secondString))

