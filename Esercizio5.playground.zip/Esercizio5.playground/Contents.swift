import Cocoa
//5. Write a Swift program to add "Is" to the front of a given string. However, if the string already begins with "Is", return the given string.
var str = "Hello, playground"

func check(stringa: String) -> String{
    var prova: String = stringa
    var returnThis: String
    let first2: String = stringa.substring(to:stringa.index(stringa.startIndex, offsetBy: 2))
    
    if first2 == "Is" {
        returnThis = stringa
    } else {
        prova += "Is"
        returnThis = prova
    }
    return returnThis
}

print(check(stringa: "Cavolfiore"))
print(check(stringa: "Issare"))
print(check(stringa: "Carissimo"))
