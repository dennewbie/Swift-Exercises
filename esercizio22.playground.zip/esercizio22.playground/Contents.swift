import Cocoa
//22. Write a Swift program to count the number of 7's in a given array of integers
var str = "Hello, playground"

func check(arrayInt: [Int]) -> Int {
    var numbOfSeven: Int = Int()
    
    for items in arrayInt {
        if items == 7 {
            numbOfSeven += 1
        }
    }
    return numbOfSeven
}

var array1: [Int] = [2, 4, 6, 7, 8, 7]

print(check(arrayInt: array1))

