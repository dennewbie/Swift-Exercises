import Cocoa
//28. Write a Swift program to test whether a value presents sequentially three times in an array of integers or not
var str = "Hello, playground"

func check(arrayInt: [Int], valueCheck: Int) {
    var count: Int = Int()
    
    for (index, number) in arrayInt.enumerated() {
        if index < arrayInt.endIndex && number == valueCheck {
            count += 1
        }
    }
    
    if count >= 3 {
        print("Il valore \(valueCheck) viene ripetuto tre o più volte.")
    } else {
         print("Il valore \(valueCheck) non viene ripetuto tre o più volte.")
    }
}

var arrayInt: [Int] = [2, 4, 7, 3, 5, 6, 7, 7]
check(arrayInt: arrayInt, valueCheck: 7)
