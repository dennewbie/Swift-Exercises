import Cocoa
//17. Write a Swift program that accept two positive integer values and test whether the larger value is in the range 20..30 inclusive, or return 0 if neither is in that range.
var str = "Hello, playground"


func check(numUno: Int, numDue: Int) -> Int {
    var returnValue: Int = Int()
    if (numUno > 0 && numDue > 0){
        if numUno > numDue {
            returnValue = largerValue(numLarger: numUno)
        } else if numDue > numUno {
            returnValue = largerValue(numLarger: numDue)
        } else {
            print("I tuoi numeri sono uguali. Riprova.")
        }
    }
    return returnValue
}

func largerValue(numLarger: Int) -> Int {
    if numLarger > 20 && numLarger <= 30 {
        return numLarger
    } else {
        return 0
    }
}

print(check(numUno: 10, numDue: 21))
print(check(numUno: 40, numDue: 50))
print(check(numUno: 30, numDue: -20))
