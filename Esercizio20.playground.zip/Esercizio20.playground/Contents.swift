import Cocoa
//20. Write a Swift program to check if the first instance of "a" in a given string is immediately followed by another "a".
var str = "Hello, playground"

func unique(_ stringa: String) -> String {
    for i in 0..<stringa.characters.count {
        for j in (i+1)..<stringa.characters.count {
            let firstIndex = stringa.index(stringa.startIndex, offsetBy: i)
            let secondIndex = stringa.index(stringa.startIndex, offsetBy: j)
            if (stringa[firstIndex] == stringa[secondIndex]) {
                return "Not all characters are unique"
            }
        }
    }
    return "All the characters are unique"
}

print(unique(str))
print(unique("Cavolfiore"))
